package com.ebazaar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbazaarApplicationTests {

	@Test
	void contextLoads() {
	}

}
