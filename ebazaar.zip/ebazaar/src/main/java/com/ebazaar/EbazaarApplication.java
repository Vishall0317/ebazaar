package com.ebazaar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbazaarApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbazaarApplication.class, args);
	}

}
